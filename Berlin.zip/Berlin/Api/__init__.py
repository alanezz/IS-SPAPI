import os
import sys
# import psycopg2
import json
from bson import json_util
import pymongo
from pymongo import MongoClient
from flask import Flask, request, session, g, redirect, url_for, abort, \
    render_template, flash


def create_app():
    app = Flask(__name__)
    return app

app = create_app()

MONGODATABASE = "escuchas2"
MONGODATABASE2 = "escuchas3"
MONGODATABASE3 = "escuchas4"
MONGODATABASE4 = "escuchas5"
MONGODATABASE5 = "escuchas6"
MONGOSERVER = "localhost"
MONGOPORT = 27017
client = MongoClient(MONGOSERVER, MONGOPORT)

@app.route("/")
def home():
    return render_template('file.html')

@app.route("/numeric/<string:label>")
def numeric(label):
    mongodb = client[MONGODATABASE]
    output = []
    label = label.replace('_', ' ')
    for s in mongodb.escuchas2.find({"bindings.l.value": label}, {"bindings.$": 1, "_id": 0}):
        output.append(s)
    temporal = {}
    try:
        for data in output[0]['bindings']:
            for key in data.keys():
                if 'p' in key:
                    temporal[key] = int(data[key]['value'])
    except IndexError:
        pass
    return json.dumps(temporal)

@app.route("/textual/<string:label>")
def textual(label):
    mongodb = client[MONGODATABASE2]
    output = []
    label = label.replace('_', ' ')
    for s in mongodb.escuchas3.find({"bindings.l.value": label}, {"bindings.$": 1, "_id": 0}):
        output.append(s)
    temporal = {}
    try:
        for data in output[0]['bindings']:
            for key in data.keys():
                if 'p' in key:
                    temporal[key] = data[key]['value']
    except IndexError:
        pass
    return json.dumps(temporal)

@app.route("/features/<string:label>")
def features(label):
    mongodb = client[MONGODATABASE3]
    output = []
    label = label.replace('_', ' ')
    for s in mongodb.escuchas4.aggregate([{'$unwind': '$bindings'}, {'$match': {"bindings.l.value": {"$in": [label]}}},
    {'$group': {'_id': '$_id', 'bindings': {'$push': '$bindings'}}}]):
        output.append(s)
    listed_output = []
    for result in output[0]['bindings']:
        listed_output.append(result['lf']['value'])
    return json.dumps({"values": listed_output})

@app.route("/review/<string:ids>")
def review(ids):
    mongodb = client[MONGODATABASE4]
    output = []
    for s in mongodb.escuchas5.find({"bindings.id.value": ids}, {"bindings.$": 1, "_id": 0}):
        output.append(s)
    temporal = {}
    try:
        for data in output[0]['bindings']:
            for key in data.keys():
                if 'id' in key:
                    temporal[key] = int(data[key]['value'])
                else:
                    temporal[key] = data[key]['value']
    except IndexError:
        pass
    return json.dumps(temporal)

@app.route("/offer/<string:ids>")
def offer(ids):
    mongodb = client[MONGODATABASE5]
    output = []
    for s in mongodb.escuchas6.find({"bindings.id.value": ids}, {"bindings.$": 1, "_id": 0}):
        output.append(s)
    temporal = {}
    try:
        for data in output[0]['bindings']:
            for key in data.keys():
                if 'id' in key:
                    temporal[key] = int(data[key]['value'])
                elif 'price' in key:
                    temporal[key] = float(data[key]['value'])
                else:
                    temporal[key] = data[key]['value']
    except IndexError:
        pass
    return json.dumps(temporal)

if __name__ == "__main__":
    app.run()
